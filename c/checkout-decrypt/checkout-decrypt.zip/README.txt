Checkout Decrypt
Monospace lines scramble and resolve into real copy on hover
