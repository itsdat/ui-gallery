Orbit Border Button
A light orbits the border and speeds up on hover
