const ob = document.getElementById('ob');
let timer;

ob.addEventListener('click', () => {
  ob.classList.toggle('done');
  clearTimeout(timer);
  if (ob.classList.contains('done')) {
    timer = setTimeout(() => ob.classList.remove(
      'done'), 2600);
  }
});
