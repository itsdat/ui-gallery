Ice Grid Drift
Blue dots scatter from the cursor and spring back into place
