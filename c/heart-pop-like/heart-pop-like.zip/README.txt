Heart Pop Like
Heart pops, particles burst, count rolls one digit
