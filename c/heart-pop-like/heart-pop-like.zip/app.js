const like = document.getElementById('like');

like.addEventListener('click', () => {
  const on = like.getAttribute('aria-pressed') !==
    'true';
  like.setAttribute('aria-pressed', on);
  like.setAttribute('aria-label', on ?
    'Unlike this post' : 'Like this post');
});
