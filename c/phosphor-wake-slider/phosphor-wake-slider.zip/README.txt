Phosphor Wake Slider
Drag the bars, watch the phosphor wake settle
