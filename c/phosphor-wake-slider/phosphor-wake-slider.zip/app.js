const N = 32;
const barsEl = document.getElementById('bars');
const val = document.getElementById('val');
const bars = [];
for (let i = 0; i < N; i++) {
  const b = document.createElement('div');
  b.className = 'bar';
  barsEl.appendChild(b);
  bars.push(b);
}

// head follows the pointer on a critically-damped spring; its speed makes the wake
let head = 0.3 * (N - 1),
  target = head,
  vel = 0,
  speed = 0,
  last = 0,
  run = false,
  down = false;
const clamp = (n, a, b) => Math.min(b, Math.max(a, n));

function frame(now) {
  const dt = Math.min(0.032, (now - last) / 1000 ||
  0.016);
  last = now;
  const w = 9.2,
    k = w * w;
  vel += (-k * (head - target) - 2 * w * vel) * dt;
  head += vel * dt;
  speed += (Math.abs(vel) - speed) * Math.min(1, dt * 10);
  const amp = clamp(speed / 14, 0, 1);
  bars.forEach((b, i) => {
    const d = i - head;
    const reach = d < 0 ? 9.6 : 4.2;
    const lift = Math.abs(d) < reach ? Math.pow(Math
      .cos((d / reach) * Math.PI / 2), 2) * amp : 0;
    b.style.transform =
      `scaleY(${(0.214 + lift * 0.786).toFixed(3)})`;
    b.classList.toggle('lit', i <= Math.round(head));
  });
  const pct = Math.round(clamp(head / (N - 1), 0, 1) *
    100);
  val.textContent = pct;
  barsEl.setAttribute('aria-valuenow', pct);
  if (down || Math.abs(vel) > 0.02 || Math.abs(head -
      target) > 0.02 || speed > 0.05)
    requestAnimationFrame(frame);
  else run = false;
}
const kick = () => {
  if (!run) {
    run = true;
    last = performance.now();
    requestAnimationFrame(frame);
  }
};
const setFrom = (e) => {
  const r = barsEl.getBoundingClientRect();
  target = clamp((e.clientX - r.left) / r.width, 0, 1) *
    (N - 1);
  kick();
};
barsEl.addEventListener('pointerdown', (e) => {
  down = true;
  barsEl.setPointerCapture(e.pointerId);
  setFrom(e);
});
barsEl.addEventListener('pointermove', (e) => {
  if (down) setFrom(e);
});
['pointerup', 'pointercancel'].forEach((n) => barsEl
  .addEventListener(n, () => {
    down = false;
    kick();
  }));
barsEl.addEventListener('keydown', (e) => {
  const step = e.key === 'ArrowRight' ? 1 : e.key ===
    'ArrowLeft' ? -1 : 0;
  if (step) {
    e.preventDefault();
    target = clamp(target + step, 0, N - 1);
    kick();
  }
});
kick();
