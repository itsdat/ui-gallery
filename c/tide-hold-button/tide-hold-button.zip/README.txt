Tide Hold Button
Hold to publish: a wavy blue tide sweeps in, then a check pops
