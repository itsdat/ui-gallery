Tide Hold Button
Hold to publish — wavy tide fills, soft ring on land
