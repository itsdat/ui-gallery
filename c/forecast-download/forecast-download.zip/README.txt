Forecast Download
Button fills into a bar, then snaps to a check.
