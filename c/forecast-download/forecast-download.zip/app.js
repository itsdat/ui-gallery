const btn = document.getElementById('dl');
const pct = document.getElementById('pct');
const meta = document.getElementById('meta');
const D = 1900;

function run() {
  btn.dataset.s = 'load';
  const t0 = performance.now();
  (function tick(now) {
    const p = Math.min(1, (now - t0) / D);
    const e = 1 - Math.pow(1 - p, 2.2);
    btn.style.setProperty('--p', e);
    btn.style.background = '';
    btn.style.setProperty('--fill', e);
    btn.querySelector(':scope') && null;
    btn.style.setProperty('--scale', e);
    btn.style.setProperty('--prog', e);
    pct.textContent = Math.round(e * 100) + '%';
    meta.textContent = 'weather-pack.zip · ' + (12.4 *
      e).toFixed(1) + ' / 12.4 MB';
    if (p < 1) requestAnimationFrame(tick);
    else {
      btn.dataset.s = 'done';
      meta.textContent = 'Saved to Downloads';
    }
  })(t0);
}

// drive the fill layer via inline scaleX on ::before using a CSS var
btn.addEventListener('click', () => {
  if (btn.dataset.s === 'idle') {
    run();
  } else if (btn.dataset.s === 'done') {
    btn.dataset.s = 'idle';
    pct.textContent = '0%';
    meta.textContent = 'weather-pack.zip · 12.4 MB';
  }
});
