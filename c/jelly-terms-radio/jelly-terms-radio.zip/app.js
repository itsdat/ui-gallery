const jr = document.getElementById('jr');
const thumb = document.getElementById('thumb');
const clone = document.getElementById('clone');
const chips = [...jr.querySelectorAll('.chip')];
chips.forEach((c) => {
  const s = document.createElement('span');
  s.textContent = c.textContent;
  clone.appendChild(s);
});

// leading edge snaps fast, trailing edge lags on a softer spring: that gap is the jelly stretch
const edge = (x) => ({
  x,
  v: 0
});
let L = edge(0),
  R = edge(0),
  tL = 0,
  tR = 0,
  kL = 700,
  kR = 700,
  last = 0,
  run = false,
  cur = 0;

function layout() {
  const c = chips[cur];
  tL = c.offsetLeft;
  tR = c.offsetLeft + c.offsetWidth;
}

function step(e, target, k, d, dt) {
  e.v += (-k * (e.x - target) - d * e.v) * dt;
  e.x += e.v * dt;
}

function frame(now) {
  const dt = Math.min(0.032, (now - last) / 1000 ||
  0.016);
  last = now;
  step(L, tL, kL, 2 * Math.sqrt(kL) * 0.55, dt);
  step(R, tR, kR, 2 * Math.sqrt(kR) * 0.55, dt);
  const w = Math.max(40, R.x - L.x);
  // stronger, more visible squash/stretch while the pill travels
  const stretch = Math.min(0.28, Math.abs(w - chips[cur]
    .offsetWidth) / 260);
  const squash = 1 - stretch;
  thumb.style.width = w + 'px';
  thumb.style.transform =
    `translateX(${L.x}px) scaleY(${squash})`;
  clone.style.left = -L.x + 'px';
  const busy = Math.abs(L.v) + Math.abs(R.v) > 0.5 || Math
    .abs(L.x - tL) > 0.2 || Math.abs(R.x - tR) > 0.2;
  if (busy) requestAnimationFrame(frame);
  else run = false;
}

function select(i) {
  const dir = i >= cur ? 1 : -1;
  cur = i;
  chips.forEach((c, n) => c.setAttribute('aria-checked',
    n === i));
  layout();
  // wider spring spread = bigger, more legible jelly stretch
  kL = dir > 0 ? 260 : 780;
  kR = dir > 0 ? 780 : 260;
  if (!run) {
    run = true;
    last = performance.now();
    requestAnimationFrame(frame);
  }
}
chips.forEach((c, i) => c.addEventListener('click', () =>
  select(i)));
layout();
L = edge(tL);
R = edge(tR);
thumb.style.width = (tR - tL) + 'px';
thumb.style.transform = `translateX(${tL}px)`;
select(0);
