const grid = document.getElementById('grid');
const cards = [...grid.querySelectorAll('.card')];

// one listener drives the light across every card
function move(e) {
  cards.forEach((c) => {
    const r = c.getBoundingClientRect();
    c.style.setProperty('--x', e.clientX - r.left +
      'px');
    c.style.setProperty('--y', e.clientY - r.top +
      'px');
  });
}

grid.addEventListener('mousemove', move);
