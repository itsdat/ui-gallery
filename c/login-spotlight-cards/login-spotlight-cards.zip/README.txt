Login Spotlight Cards
One cursor light glides across three glass cards
