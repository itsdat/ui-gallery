Mono Spotlight Deck
One soft light glides across all cards, tracing hairline borders
