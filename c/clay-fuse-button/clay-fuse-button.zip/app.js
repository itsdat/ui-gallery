const fuse = document.getElementById('fuse');
const rect = fuse.querySelector('rect');

fuse.addEventListener('click', () => {
  const s = fuse.dataset.state;
  fuse.dataset.state = s === 'idle' ? 'burning' :
    'idle';
});

rect.addEventListener('animationend', () => {
  if (fuse.dataset.state === 'burning') {
    fuse.dataset.state = 'done';
  }
});
