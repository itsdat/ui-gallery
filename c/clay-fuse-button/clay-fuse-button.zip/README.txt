Clay Fuse Button
Amber fuse burns around a clay pill, then snaps to Archived
