Mono Folder Fan
Hover to fan cards, drag them around, spring physics
