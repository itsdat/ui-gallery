Clay Orbit Button
A soft clay spark orbits the rim, speeding up on hover
