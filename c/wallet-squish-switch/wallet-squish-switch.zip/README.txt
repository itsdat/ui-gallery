Wallet Squish Switch
Spring-driven pill that stretches as it travels
