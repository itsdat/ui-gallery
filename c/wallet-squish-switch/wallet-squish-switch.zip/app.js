const btn = document.getElementById('ss');
const thumb = btn.querySelector('.thumb');
const MIN = 8;
const MAX = 152 - 8 - 56;
let x = MIN,
  v = 0,
  target = MIN,
  flow = 0;
let swell = 1,
  swellT = 1,
  last = 0,
  running = false;

function frame(now) {
  const dt = Math.min(0.032, (now - last) / 1000 ||
  0.016);
  last = now;
  const a = (-170 * (x - target) - 21.5 * v) / 0.9;
  v += a * dt;
  x += v * dt;
  flow += (v - flow) * Math.min(1, dt * 14);
  swell += (swellT - swell) * Math.min(1, dt * 18);
  const s = 1 + Math.min(0.4, Math.abs(flow) / 600) *
  0.36;
  thumb.style.transform =
    `translateX(${x.toFixed(2)}px) scale(${(s * swell).toFixed(3)}, ${(swell / s).toFixed(3)})`;
  if (Math.abs(v) > 0.05 || Math.abs(x - target) > 0.05 ||
    Math.abs(swell - swellT) > 0.001)
    requestAnimationFrame(frame);
  else running = false;
}

function kick() {
  if (!running) {
    running = true;
    last = performance.now();
    requestAnimationFrame(frame);
  }
}

btn.addEventListener('click', () => {
  const on = btn.getAttribute('aria-checked') !==
    'true';
  btn.setAttribute('aria-checked', on);
  target = on ? MAX : MIN;
  kick();
});
btn.addEventListener('pointerenter', () => {
  swellT = 1.035;
  kick();
});
btn.addEventListener('pointerleave', () => {
  swellT = 1;
  kick();
});

thumb.style.transform = `translateX(${MIN}px)`;
