Machined Notify Bell
Invert, ring, overshoot badge pop on machined hardware
