const bell = document.getElementById('bell');
bell.addEventListener('click', () => {
  const on = bell.getAttribute('aria-pressed') !==
    'true';
  bell.setAttribute('aria-pressed', on);
  if (on) {
    // restart the ring animation on every activation
    const ico = bell.querySelector('.ico');
    ico.style.animation = 'none';
    void ico.offsetWidth;
    ico.style.animation = '';
  }
});
