const root = document.getElementById('otp');
const input = document.getElementById('otpIn');
const slots = [...root.querySelectorAll('.slot')];
const caret = root.querySelector('.caret');
const hint = root.querySelector('.hint');
const STEP = 54 + 10;
root.classList.add('idle');

function paint() {
  const v = input.value.replace(/\D/g, '').slice(0, 6);
  input.value = v;
  slots.forEach((s, i) => {
    const had = s.classList.contains('full');
    const digit = v[i] || '';
    if (s.firstChild.textContent !== digit) s
      .firstChild.textContent = digit;
    s.classList.toggle('full', i < v.length);
    s.classList.toggle('on', i === v.length &&
      document.activeElement === input);
    if (i < v.length && !had) {
      s.firstChild.style.transition = 'none';
      s.firstChild.style.transform =
        'translateY(-12px) scale(.8)';
      s.firstChild.offsetWidth;
      s.firstChild.style.transition = '';
      s.firstChild.style.transform = '';
    }
  });
  caret.style.transform =
    `translateX(${Math.min(v.length, 5) * STEP + 26}px)`;
  root.classList.toggle('idle', document.activeElement !==
    input && !v.length);
  if (v.length === 6) {
    root.classList.add('ok');
    hint.textContent = 'Code verified';
    input.blur();
    setTimeout(reset, 2200);
  }
}

function reset() {
  root.classList.remove('ok', 'err');
  input.value = '';
  hint.textContent = 'Enter the 6-digit code';
  slots.forEach((s) => s.classList.remove('full', 'on'));
  paint();
}

input.addEventListener('input', paint);
input.addEventListener('focus', paint);
input.addEventListener('blur', () => {
  if (!root.classList.contains('ok')) paint();
});
