Aurora Code Slots
Springy OTP boxes with a centre wash reveal
