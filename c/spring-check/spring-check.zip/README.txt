Spring Check
One spring drives fill, tick draw and strike-through
