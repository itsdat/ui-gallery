// one damped spring per row drives fill, box swell, tick draw, strike-through
const STIFF = 900,
  DAMP = 36;
document.querySelectorAll('.sc').forEach((el) => {
  const q = (s) => el.querySelector(s);
  const box = q('.box'),
    fill = q('.fill'),
    tick = q('.tick path'),
    word = q('.word'),
    rule = q('.rule');
  let t = 0,
    v = 0,
    target = 0,
    last = 0,
    run = false;
  const clamp = (n) => Math.min(1, Math.max(0, n));

  const draw = () => {
    const h = clamp(t);
    fill.style.transform =
      `scale(${Math.max(t, 0)})`;
    box.style.transform =
      `scale(${1 + 0.22 * Math.max(0, t - 1)})`;
    tick.style.strokeDashoffset = 1 - h;
    word.style.opacity = 1 - 0.55 * h;
    rule.style.transform =
      `scaleX(${clamp((h - 0.12) / 0.72)})`;
  };

  const frame = (now) => {
    const dt = Math.min(0.032, (now - last) /
      1000 || 0.016);
    last = now;
    v += (-STIFF * (t - target) - DAMP * v) * dt;
    t += v * dt;
    draw();
    if (Math.abs(v) > 0.002 || Math.abs(t -
      target) > 0.001) {
      requestAnimationFrame(frame);
    } else {
      t = target;
      draw();
      run = false;
    }
  };

  el.addEventListener('pointerdown', () => el
    .classList.add('down'));
  ['pointerup', 'pointerleave'].forEach((e) =>
    el.addEventListener(e, () => el.classList
      .remove('down')));
  el.addEventListener('click', () => {
    const on = el.getAttribute('aria-checked') !==
      'true';
    el.setAttribute('aria-checked', on);
    target = on ? 1 : 0;
    if (!run) {
      run = true;
      last = performance.now();
      requestAnimationFrame(frame);
    }
  });
  draw();
});
