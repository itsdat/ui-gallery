const tabs = [...document.querySelectorAll('.tab')];
const pill = document.getElementById('pill');
const num = document.getElementById('num');
const cap = document.getElementById('cap');
const delta = document.getElementById('delta');
const panel = document.querySelector('.panel');
let current = 12480,
  raf = 0;

const place = (t) => {
  pill.style.left = t.offsetLeft + 'px';
  pill.style.width = t.offsetWidth + 'px';
};

const count = (to) => {
  cancelAnimationFrame(raf);
  const from = current,
    t0 = performance.now();
  (function step(now) {
    const p = Math.min(1, (now - t0) / 700),
      e = 1 - Math.pow(1 - p, 3);
    current = Math.round(from + (to - from) * e);
    num.textContent = current.toLocaleString('en-US');
    if (p < 1) raf = requestAnimationFrame(step);
  })(t0);
};

tabs.forEach((t) => t.addEventListener('click', () => {
  tabs.forEach((x) => x.classList.toggle('on', x ===
    t));
  place(t);
  count(+t.dataset.n);
  cap.textContent = t.dataset.c;
  delta.textContent = t.dataset.d;
  panel.classList.add('swap');
  setTimeout(() => {
    panel.classList.remove('swap');
    panel.querySelectorAll('.bar').forEach((
      b) => {
        b.style.animation = 'none';
        void b.offsetWidth;
        b.style.animation = '';
      });
  }, 180);
}));

requestAnimationFrame(() => place(tabs[0]));
