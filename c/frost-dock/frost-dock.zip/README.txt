Frost Dock
Icons swell toward the cursor, neighbours ride along
