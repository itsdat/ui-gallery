const dock = document.getElementById('dock');
const items = [...dock.querySelectorAll('.it')];
const BASE = 52,
  GAIN = 46,
  SPREAD = 78;

function set(x) {
  let hot = null,
    best = 1e9;
  items.forEach((el) => {
    el.style.transition = 'none';
    const r = el.getBoundingClientRect();
    const d = x == null ? 1e3 : Math.abs(x - (r.left +
      r.width / 2));
    const size = BASE + GAIN * Math.exp(-(d * d) / (
      2 * SPREAD * SPREAD));
    el.style.width = el.style.height = size + 'px';
    if (d < best) {
      best = d;
      hot = el;
    }
  });
  items.forEach((el) => el.classList.toggle('on', el ===
    hot && best < 40));
}

dock.addEventListener('mousemove', (e) => set(e.clientX));
dock.addEventListener('mouseleave', () => {
  items.forEach((el) => {
    el.style.transition =
      'width .35s cubic-bezier(.34,1.56,.64,1), height .35s cubic-bezier(.34,1.56,.64,1)';
    el.style.width = el.style.height = '';
    el.classList.remove('on');
  });
});
