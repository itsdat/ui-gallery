Morph Download Button
Download button fills, morphs into a bouncing check
