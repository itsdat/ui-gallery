const btn = document.getElementById('dl');
const fill = document.getElementById('fill');
const pct = document.getElementById('pct');
const meta = document.getElementById('meta');
const IDLE = 'release-4.zip · 12.4 MB';

function run() {
  btn.dataset.s = 'load';
  fill.style.transform = 'scaleX(0)';
  const t0 = performance.now(),
    D = 1900;
  (function tick(now) {
    const p = Math.min(1, (now - t0) / D),
      e = 1 - Math.pow(1 - p, 2.2);
    fill.style.transform = 'scaleX(' + e + ')';
    pct.textContent = Math.round(e * 100) + '%';
    meta.textContent = 'release-4.zip · ' + (12.4 * e)
      .toFixed(1) + ' / 12.4 MB';
    if (p < 1) requestAnimationFrame(tick);
    else {
      btn.dataset.s = 'done';
      meta.textContent = 'Saved to Downloads';
    }
  })(t0);
}

btn.addEventListener('click', () => {
  if (btn.dataset.s === 'idle') run();
  else if (btn.dataset.s === 'done') {
    btn.dataset.s = 'idle';
    fill.style.transform = 'scaleX(0)';
    pct.textContent = '0%';
    meta.textContent = IDLE;
  }
});
