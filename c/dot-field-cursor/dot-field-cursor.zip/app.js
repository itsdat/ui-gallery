const field = document.getElementById('field');
const dotsEl = document.getElementById('dots');
const cta = document.getElementById('cta');
const R = 120;
for (let i = 0; i < 286; i++) dotsEl.appendChild(document
  .createElement('i'));
const dots = [...dotsEl.children];
let centers = [];
let raf = 0;

const measure = () => {
  centers = dots.map((d) => {
    const r = d.getBoundingClientRect();
    return [r.left + r.width / 2, r.top + r.height /
      2
    ];
  });
};
measure();
field.classList.add('idle');

field.addEventListener('mousemove', (e) => {
  field.classList.remove('idle');
  cancelAnimationFrame(raf);
  dots.forEach((d, i) => {
    const dx = centers[i][0] - e.clientX,
      dy = centers[i][1] - e.clientY;
    const dist = Math.hypot(dx, dy),
      f = Math.max(0, 1 - dist / R);
    const push = f * f * 24;
    d.style.setProperty('--tx', (dx / (dist ||
      1)) * push + 'px');
    d.style.setProperty('--ty', (dy / (dist ||
      1)) * push + 'px');
    d.style.setProperty('--s', 1 + f * 2.4);
    d.style.setProperty('--f', f.toFixed(3));
  });
  const r = cta.getBoundingClientRect(),
    cx = r.left + r.width / 2,
    cy = r.top + r.height / 2;
  const d = Math.hypot(e.clientX - cx, e.clientY -
  cy);
  cta.classList.toggle('pull', d < R);
  const k = d < R ? 0.28 : 0;
  cta.style.setProperty('--mx', (e.clientX - cx) * k +
    'px');
  cta.style.setProperty('--my', (e.clientY - cy) * k +
    'px');
});

field.addEventListener('mouseleave', () => {
  field.classList.add('idle');
  dots.forEach((d) => {
    ['--tx', '--ty', '--f'].forEach((p) => d.style
      .setProperty(p, '0'));
    d.style.setProperty('--s', 1);
  });
  cta.classList.remove('pull');
  cta.style.setProperty('--mx', '0px');
  cta.style.setProperty('--my', '0px');
});
