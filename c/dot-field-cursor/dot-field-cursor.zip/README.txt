Dot Field Cursor
Dots scatter from cursor and spring back with a glow
