Ticket Dock
Brutalist dock that magnifies icons by cursor distance
