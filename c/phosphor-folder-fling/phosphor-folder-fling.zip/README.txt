Phosphor Folder Fling
Hover tilts the flap; cards spring out and drag free
