const ff = document.getElementById('ff');
const hit = document.getElementById('hit');
const sub = document.getElementById('sub');
const notes = [...ff.querySelectorAll('.note')];
const GAP = 10,
  ROW = 46,
  LIFT = 22,
  SPREAD = 190;
const jit = (i) => {
  const x = Math.sin(i * 12.9898 + 4.1414) * 43758.5453;
  return x - Math.floor(x);
};
let pos = [],
  body = [],
  drag = null,
  live = false,
  timer = 0;

function layout() {
  const rows = [];
  let row = [],
    w = 0;
  notes.forEach((n, i) => {
    const pw = n.offsetWidth;
    if (row.length && w + GAP + pw > SPREAD * 1.8) {
      rows.push({
        row,
        w
      });
      row = [];
      w = 0;
    }
    row.push({
      i,
      pw
    });
    w += (row.length > 1 ? GAP : 0) + pw;
  });
  rows.push({
    row,
    w
  });
  rows.forEach((r, ri) => {
    let x = -r.w / 2;
    const shift = (ri % 2 ? 1 : -1) * 14;
    r.row.forEach(({
      i,
      pw
    }) => {
      const j = jit(i);
      pos[i] = {
        x: x + pw / 2 + shift,
        y: -LIFT - ri * ROW - j * 6,
        r: (j * 2 - 1) * 7
      };
      x += pw + GAP;
    });
  });
  notes.forEach((n, i) => {
    n.style.setProperty('--i', i);
    n.style.setProperty('--x', pos[i].x.toFixed(1) +
      'px');
    n.style.setProperty('--y', pos[i].y.toFixed(1) +
      'px');
    n.style.setProperty('--r', pos[i].r.toFixed(1) +
      'deg');
  });
}
layout();
document.fonts && document.fonts.ready.then(layout);

function start() {
  if (live) return;
  live = true;
  ff.classList.add('live');
  const H = notes.map((n) => n.offsetHeight);
  const W = notes.map((n) => n.offsetWidth);
  body = notes.map((n, i) => ({
    x: pos[i].x,
    y: pos[i].y + H[i] / 2,
    vx: 0,
    vy: 0,
    w: W[i],
    h: H[i],
    ph: jit(i) * 6.28,
    tilt: pos[i].r
  }));
  const top = Math.min(...body.map((b) => b.y - b.h /
    2)) - 10;
  const bottom = -LIFT + Math.max(...H);
  const t0 = performance.now();
  let last = 0;
  (function step(now) {
    if (!live) return;
    const dt = Math.min(32, last ? now - last : 16),
      t = (now - t0) / 1000;
    last = now;
    body.forEach((b, i) => {
      if (drag && drag.i === i) return;
      const k = 0.000035 * Math.min(1, t / 2) * dt;
      b.vx += Math.sin(t * 0.9 + b.ph) * k;
      b.vy += Math.cos(t * 1.3 + b.ph * 1.7) * k;
      b.vx *= Math.pow(0.94, dt / 16);
      b.vy *= Math.pow(0.94, dt / 16);
      b.x += b.vx * dt;
      b.y += b.vy * dt;
    });
    for (let a = 0; a < body.length; a++) {
      for (let c = a + 1; c < body.length; c++) {
        const A = body[a],
          B = body[c],
          dx = B.x - A.x,
          dy = B.y - A.y;
        const ox = (A.w + B.w) / 2 - Math.abs(dx),
          oy = (A.h + B.h) / 2 - Math.abs(dy);
        if (ox <= 0 || oy <= 0) continue;
        const ad = drag && drag.i === a,
          bd = drag && drag.i === c;
        const sa = ad ? 0 : bd ? 1 : 0.5,
          sb = bd ? 0 : ad ? 1 : 0.5;
        if (ox < oy) {
          const s = Math.sign(dx) || 1,
            imp = (B.vx - A.vx) * 0.75;
          A.x -= s * ox * sa;
          B.x += s * ox * sb;
          if (imp * s < 0) {
            A.vx += imp * sa;
            B.vx -= imp * sb;
          }
          B.vx += s * 0.1 * sb;
          A.vx -= s * 0.1 * sa;
        } else {
          const s = Math.sign(dy) || 1,
            imp = (B.vy - A.vy) * 0.75;
          A.y -= s * oy * sa;
          B.y += s * oy * sb;
          if (imp * s < 0) {
            A.vy += imp * sa;
            B.vy -= imp * sb;
          }
          B.vy += s * 0.1 * sb;
          A.vy -= s * 0.1 * sa;
        }
      }
    }
    body.forEach((b, i) => {
      const minX = -SPREAD + b.w / 2,
        maxX = SPREAD - b.w / 2;
      const minY = top + b.h / 2,
        maxY = bottom - b.h / 2;
      if (b.x < minX) {
        b.x = minX;
        b.vx = Math.abs(b.vx) * 0.5;
      }
      if (b.x > maxX) {
        b.x = maxX;
        b.vx = -Math.abs(b.vx) * 0.5;
      }
      if (b.y < minY) {
        b.y = minY;
        b.vy = Math.abs(b.vy) * 0.5;
      }
      if (b.y > maxY) {
        b.y = maxY;
        b.vy = -Math.abs(b.vy) * 0.5;
      }
      b.tilt += (Math.max(-12, Math.min(12, pos[i]
        .r + b.vx * 50)) - b.tilt) * 0.15;
      notes[i].style.setProperty('--x', b.x.toFixed(
        1) + 'px');
      notes[i].style.setProperty('--y', (b.y - b.h /
        2).toFixed(1) + 'px');
      notes[i].style.setProperty('--r', b.tilt
        .toFixed(2) + 'deg');
    });
    requestAnimationFrame(step);
  })(t0);
}

function open() {
  if (ff.classList.contains('open')) return;
  ff.classList.add('open');
  clearTimeout(timer);
  timer = setTimeout(start, 520 + 3 * 40 + 80);
}

function close() {
  clearTimeout(timer);
  live = false;
  drag = null;
  ff.classList.remove('open', 'live');
}

ff.addEventListener('pointerenter', open);
ff.addEventListener('pointerleave', () => {
  if (!drag) close();
});
hit.addEventListener('click', () => (ff.classList
  .contains('open') ? close() : open()));

const toLocal = (e) => {
  const r = ff.getBoundingClientRect(),
    k = r.width / ff.offsetWidth;
  return {
    x: (e.clientX - (r.left + r.width / 2)) / k,
    y: (e.clientY - (r.top + 14 * k)) / k
  };
};
notes.forEach((n, i) => {
  n.addEventListener('pointerdown', (e) => {
    if (!live) return;
    const p = toLocal(e);
    drag = {
      i,
      sx: e.clientX,
      sy: e.clientY,
      dx: body[i].x - p.x,
      dy: body[i].y - p.y,
      moved: false
    };
    try {
      n.setPointerCapture(e.pointerId);
    } catch (_) {}
  });
  n.addEventListener('pointermove', (e) => {
    if (!drag || drag.i !== i) return;
    if (!drag.moved && Math.hypot(e.clientX - drag
        .sx, e.clientY - drag.sy) > 4) {
      drag.moved = true;
      n.classList.add('drag');
    }
    if (!drag.moved) return;
    const p = toLocal(e),
      b = body[i];
    const nx = p.x + drag.dx,
      ny = p.y + drag.dy;
    b.vx = (nx - b.x) * 0.05;
    b.vy = (ny - b.y) * 0.05;
    b.x = nx;
    b.y = ny;
  });
  const up = () => {
    if (!drag || drag.i !== i) return;
    const moved = drag.moved;
    drag = null;
    n.classList.remove('drag');
    if (!moved) pick(n);
  };
  n.addEventListener('pointerup', up);
  n.addEventListener('pointercancel', up);
});

function pick(n) {
  n.classList.add('pop');
  sub.textContent = 'Marked: ' + n.textContent;
  setTimeout(() => n.classList.remove('pop'), 320);
  close();
}
