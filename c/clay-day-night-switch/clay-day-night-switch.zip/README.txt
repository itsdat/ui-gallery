Clay Day/Night Switch
A tiny pom-pom sun rolls under the hills; night falls inside the pill
