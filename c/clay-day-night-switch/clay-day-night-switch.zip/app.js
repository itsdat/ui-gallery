const sw = document.getElementById('sw');

sw.addEventListener('click', () => {
  const night = sw.getAttribute('aria-checked') ===
    'true';
  sw.setAttribute('aria-checked', night ? 'false' :
    'true');
});
