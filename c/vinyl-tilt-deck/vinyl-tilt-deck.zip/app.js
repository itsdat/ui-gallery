const area = document.getElementById('area');
const card = document.getElementById('card');
const MAX = 12;

area.addEventListener('mousemove', (e) => {
  const r = card.getBoundingClientRect();
  const px = (e.clientX - r.left) / r.width;
  const py = (e.clientY - r.top) / r.height;
  const cx = Math.max(-0.3, Math.min(1.3, px));
  const cy = Math.max(-0.3, Math.min(1.3, py));
  card.classList.add('live');
  card.style.setProperty('--ry', (cx - 0.5) * MAX *
    2 + 'deg');
  card.style.setProperty('--rx', -(cy - 0.5) * MAX *
    2 + 'deg');
  card.style.setProperty('--gx', px * 100 + '%');
  card.style.setProperty('--gy', py * 100 + '%');
});

area.addEventListener('mouseleave', () => {
  card.classList.remove('live');
  card.style.setProperty('--rx', '0deg');
  card.style.setProperty('--ry', '0deg');
});
