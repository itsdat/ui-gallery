Tide Seal Button
Hold to sweep a wavy accent tide across the pill
