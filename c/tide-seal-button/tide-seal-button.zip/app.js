const btn = document.getElementById('hb');
const label = btn.querySelector('.label');
const HOLD = 1500,
  RELEASE = 200;
let p = 0,
  raf = 0,
  timer = 0;

btn.querySelectorAll('.fill, .crest').forEach((el) =>
  el.appendChild(label.cloneNode(true)));
btn.style.setProperty('--w', btn.offsetWidth + 'px');
btn.style.setProperty('--h', btn.offsetHeight + 'px');

const easeOut = (t) => 1 - Math.pow(1 - t, 3);

function drive(to, ms, ease) {
  cancelAnimationFrame(raf);
  const from = p,
    t0 = performance.now();
  (function step(now) {
    const t = ms > 0 ? Math.min(1, (now - t0) / ms) : 1;
    p = from + (to - from) * ease(t);
    btn.style.setProperty('--p', p.toFixed(4));
    if (t < 1) raf = requestAnimationFrame(step);
    else if (to === 1) finish();
  })(t0);
}

function finish() {
  if (btn.dataset.phase !== 'holding') return;
  btn.dataset.phase = 'done';
  timer = setTimeout(() => {
    btn.dataset.phase = 'idle';
    drive(0, RELEASE, easeOut);
  }, 1200);
}

btn.addEventListener('pointerdown', (e) => {
  if (btn.dataset.phase !== 'idle') return;
  btn.dataset.phase = 'holding';
  drive(1, HOLD, (t) => t);
  try {
    btn.setPointerCapture(e.pointerId);
  } catch (_) {}
});

function release() {
  if (btn.dataset.phase !== 'holding') return;
  btn.dataset.phase = 'idle';
  drive(0, RELEASE, easeOut);
}
btn.addEventListener('pointerup', release);
btn.addEventListener('pointercancel', release);
