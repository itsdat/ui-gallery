Fitness Tracker Tabs
Springy neumorph pill glides under tabs, stats blur-fade
