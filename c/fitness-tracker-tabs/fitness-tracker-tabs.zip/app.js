const tabs = [...document.querySelectorAll('.tab')];
const pill = document.getElementById('pill');
const num = document.getElementById('num');
const cap = document.getElementById('cap');
const delta = document.getElementById('delta');
const panel = document.querySelector('.panel');
const spark = document.querySelector('.spark');
const line = document.getElementById('line');
const LINES = [
  'M0 38 C30 30 50 40 80 26 S130 30 160 18 S230 24 300 6',
  'M0 30 C40 40 60 10 100 22 S160 44 200 20 S260 12 300 14',
  'M0 42 C50 40 80 36 120 30 S190 20 230 16 S280 8 300 4',
  'M0 24 C30 24 60 34 100 28 S170 14 210 30 S270 26 300 20'
];
let current = 12480,
  raf = 0;

const place = (t) => {
  pill.style.left = t.offsetLeft + 'px';
  pill.style.width = t.offsetWidth + 'px';
};

const count = (to) => {
  cancelAnimationFrame(raf);
  const from = current,
    t0 = performance.now();
  (function step(now) {
    const p = Math.min(1, (now - t0) / 700),
      e = 1 - Math.pow(1 - p, 3);
    current = Math.round(from + (to - from) * e);
    num.textContent = current.toLocaleString('en-US');
    if (p < 1) raf = requestAnimationFrame(step);
  })(t0);
};

tabs.forEach((t, i) => t.addEventListener('click', () => {
  tabs.forEach((x) => x.classList.toggle('on', x ===
    t));
  place(t);
  panel.classList.add('swap');
  setTimeout(() => {
    count(+t.dataset.n);
    cap.textContent = t.dataset.c;
    delta.textContent = t.dataset.d;
    line.setAttribute('d', LINES[i]);
    panel.classList.remove('swap');
  }, 180);
  spark.classList.remove('draw');
  void spark.getBoundingClientRect();
  spark.classList.add('draw');
}));

requestAnimationFrame(() => place(tabs[0]));
