const GLYPHS = '!<>-_\\/[]{}=+*^?#%&01';
const rand = () => GLYPHS[Math.floor(Math.random() *
  GLYPHS.length)];
const scramble = (s) => s.replace(/[^ ]/g, rand);

document.querySelectorAll('li').forEach((li) => {
  const out = li.querySelector('.t');
  const target = li.dataset.t;
  let raf = 0;
  out.textContent = scramble(target);

  const decode = () => {
    cancelAnimationFrame(raf);
    const t0 = performance.now(),
      D = 900;
    (function frame(now) {
      const n = Math.floor(Math.min(1, (now -
        t0) / D) * target.length);
      const rest = target.slice(n).replace(
        /[^ ]/g, rand);
      out.innerHTML = '<span class="r">' + target
        .slice(0, n) + '</span>' + rest;
      if (n < target.length) raf =
        requestAnimationFrame(frame);
      else out.innerHTML = '<span class="r">' +
        target + '</span>';
    })(t0);
  };

  li.addEventListener('mouseenter', decode);
  li.addEventListener('mouseleave', () => {
    cancelAnimationFrame(raf);
    out.textContent = scramble(target);
  });
});
