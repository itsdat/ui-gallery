Decrypt Hover
Scrambled filenames resolve left-to-right on hover
